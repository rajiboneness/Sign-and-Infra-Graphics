@extends('admin.layouts.master')

@section('content')
    <div class="container-fluid pt-4 px-4">
    </div>
    <div class="container-fluid pt-4 px-4">
    </div>
@endsection